<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\Hugo\Desktop\Inventario GH New\InventarioGH\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>